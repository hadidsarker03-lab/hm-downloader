package com.example.fastdl

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class FeedItem(val id: String, val title: String, val sub: String, val count: Long)
data class Opt(val group: String, val label: String, val desc: String, val size: Long, val url: String, val name: String)
data class Sheet(val id: String, val title: String, val opts: List<Opt>)

/** Internet Archive (archive.org): a legal source of free / public-domain music, videos, books with many file formats. */
object Archive {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).build()
    private val cache = HashMap<String, List<FeedItem>>()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun encPath(s: String) = enc(s).replace("+", "%20")

    private fun get(url: String): String =
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            r.body!!.string()
        }

    private fun str(o: JSONObject, k: String): String {
        val v = o.opt(k) ?: return ""
        return if (v is JSONArray) (if (v.length() > 0) v.optString(0) else "") else v.toString()
    }

    fun thumb(id: String) = "https://archive.org/services/img/${encPath(id)}"

    /** media: "audio", "movies" or "any". sort e.g. "downloads desc". */
    suspend fun search(query: String?, media: String, sort: String?, rows: Int = 20): List<FeedItem> = withContext(Dispatchers.IO) {
        val key = "$media|$sort|$query|$rows"
        cache[key]?.let { return@withContext it }
        val mt = if (media == "any") "mediatype:(audio OR movies)" else "mediatype:($media)"
        val q = if (query.isNullOrBlank()) mt else "($query) AND $mt"
        var u = "https://archive.org/advancedsearch.php?q=${enc(q)}&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=downloads&rows=$rows&page=1&output=json"
        if (sort != null) u += "&sort%5B%5D=${enc(sort)}"
        val docs = JSONObject(get(u)).getJSONObject("response").getJSONArray("docs")
        val list = (0 until docs.length()).map { docs.getJSONObject(it) }.map { d ->
            FeedItem(d.getString("identifier"), str(d, "title").ifBlank { d.getString("identifier") }, str(d, "creator"), d.optLong("downloads"))
        }
        cache[key] = list
        list
    }

    private val AUDIO = setOf("mp3", "m4a", "ogg", "oga", "flac", "wav", "opus", "aac")
    private val VIDEO = setOf("mp4", "mkv", "webm", "ogv", "avi", "mov", "mpeg", "mpg", "m4v", "3gp")
    private val SUB = setOf("srt", "vtt")
    private val SKIP = setOf("xml", "torrent", "sqlite", "gz", "json", "afpk", "ia")

    /** All downloadable files of an item, grouped like Video / Music / Subtitles / Other. */
    suspend fun metadata(id: String): Sheet = withContext(Dispatchers.IO) {
        val j = JSONObject(get("https://archive.org/metadata/${encPath(id)}"))
        val title = j.optJSONObject("metadata")?.let { str(it, "title") }.orEmpty().ifBlank { id }
        val files = j.optJSONArray("files") ?: JSONArray()
        val opts = mutableListOf<Opt>()
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val name = f.optString("name")
            val ext = name.substringAfterLast('.', "").lowercase()
            val fmt = f.optString("format")
            if (ext.isEmpty() || ext in SKIP || name.startsWith("__ia_thumb") || fmt == "Item Tile" || fmt == "Metadata") continue
            val group = when (ext) { in AUDIO -> "Music"; in VIDEO -> "Video"; in SUB -> "Subtitles/CC"; else -> "Other" }
            val base = name.substringAfterLast('/')
            val url = "https://archive.org/download/${encPath(id)}/" + name.split('/').joinToString("/") { encPath(it) }
            opts.add(Opt(group, fmt.ifBlank { ext.uppercase() }, base, f.optString("size").toLongOrNull() ?: 0L, url, base))
        }
        val order = listOf("Video", "Music", "Subtitles/CC", "Other")
        Sheet(id, title, opts.sortedWith(compareBy({ order.indexOf(it.group) }, { it.size })))
    }
}
