package com.example.fastdl

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Bg = Color(0xFF181818); val Card = Color(0xFF242424); val Yellow = Color(0xFFFFCC1F); val Dim = Color(0xFF9A9A9A)

data class DlReq(val url: String, val name: String, val cookie: String?, val ua: String?, val referer: String?)

fun openFile(ctx: Context, f: DoneFile) {
    val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.name.substringAfterLast('.', "").lowercase()) ?: "*/*"
    runCatching {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(f.uri, mime)
            .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

class MainActivity : ComponentActivity() {
    private var shared by mutableStateOf<String?>(null)

    private fun handle(i: android.content.Intent?) {
        if (i?.action == android.content.Intent.ACTION_SEND) {
            val t = i?.getStringExtra(android.content.Intent.EXTRA_TEXT) ?: return
            Regex("https?://\\S+").find(t)?.value?.let { shared = it }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || !Store.clipWatch(this)) return
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString() ?: return
        val u = Regex("https?://\\S+").find(t)?.value ?: return
        if (u != Store.lastClip(this) && shared == null) { Store.setLastClip(this, u); shared = u }
    }

    override fun onNewIntent(intent: android.content.Intent) { super.onNewIntent(intent); setIntent(intent); handle(intent) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Store.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (s == null) handle(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Yellow, background = Bg, surface = Bg)) {
                App(shared) { shared = null }
            }
        }
    }
}

@Composable
fun App(shared: String?, onSharedHandled: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf<DoneFile?>(null) }
    var address by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<DlReq?>(null) }

    val web = remember {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, url: String?) { address = url ?: address }
            }
            setDownloadListener { u, ua, cd, mime, _ ->
                pending = DlReq(u, URLUtil.guessFileName(u, cd, mime), CookieManager.getInstance().getCookie(u), ua, this.url)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { web.destroy() } }
    LaunchedEffect(Unit) { if (web.url == null) web.loadUrl("https://www.google.com") }
    BackHandler(enabled = tab == 1) { if (web.canGoBack()) web.goBack() else tab = 0 }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Bg) {
                listOf(Icons.Default.Search to "Download", Icons.Default.Public to "Browser",
                    Icons.Default.PlayCircle to "Play", Icons.Default.Settings to "Settings")
                    .forEachIndexed { i, (ic, label) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(ic, label) }, label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White,
                                selectedTextColor = Color.White, indicatorColor = Card,
                                unselectedIconColor = Dim, unselectedTextColor = Dim))
                    }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> DownloadTab { tab = 2 }
                1 -> BrowserTab(web, address)
                2 -> PlayTab { f ->
                    val c = Store.category(f.name)
                    if (c == Store.Cat.VIDEO || c == Store.Cat.AUDIO) playing = f else openFile(ctx, f)
                }
                else -> SettingsTab()
            }
        }
    }

    playing?.let { PlayerDialog(it) { playing = null } }
    shared?.let { u ->
        AlertDialog(onDismissRequest = onSharedHandled, containerColor = Bg,
            title = { Text("লিংক পাওয়া গেছে") },
            text = { Text(u, maxLines = 4, fontSize = 13.sp) },
            confirmButton = { TextButton(onClick = { DownloadService.start(ctx, u); onSharedHandled(); tab = 2 }) { Text("Download", color = Yellow) } },
            dismissButton = { TextButton(onClick = { web.loadUrl(u); onSharedHandled(); tab = 1 }) { Text("Browser এ খুলুন", color = Dim) } })
    }
    pending?.let { r ->
        AlertDialog(
            onDismissRequest = { pending = null }, containerColor = Bg,
            title = { Text("ডাউনলোড করবেন?") },
            text = { Text(r.name, fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = { DownloadService.start(ctx, r.url, r.name, r.cookie, r.ua, r.referer); pending = null; tab = 2 }) { Text("Download", color = Yellow) }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel", color = Dim) } },
        )
    }
}

@Composable
fun DownloadTab(onStarted: () -> Unit) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("HM DOWNLOADER", color = Yellow, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            value = url, onValueChange = { url = it; err = null }, singleLine = true,
            placeholder = { Text("ফাইলের লিংক পেস্ট করুন", color = Dim) },
            shape = RoundedCornerShape(32.dp), modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.ContentPaste, null, Modifier.clickable {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                url = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: url
            }) },
            trailingIcon = {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Yellow).clickable {
                    val u = url.trim()
                    if (u.startsWith("http://") || u.startsWith("https://")) {
                        DownloadService.start(ctx, u); url = ""; onStarted()
                    } else err = "সঠিক http/https লিংক দিন"
                }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Download, null, tint = Color.Black) }
            },
            isError = err != null, supportingText = { err?.let { Text(it) } },
        )
        Spacer(Modifier.height(12.dp))
        Text("সরাসরি ফাইল লিংক (mp4, mp3, zip, apk, pdf…) দিন", color = Dim, fontSize = 12.sp)
        Text("অথবা Browser ট্যাবে সাইট খুলে ফাইলে ট্যাপ করুন", color = Dim, fontSize = 12.sp)
    }
}

@Composable
fun BrowserTab(web: WebView, address: String) {
    var text by remember(address) { mutableStateOf(address) }
    fun go() {
        val t = text.trim(); if (t.isEmpty()) return
        web.loadUrl(when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains('.') && !t.contains(' ') -> "https://$t"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
        })
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (web.canGoBack()) web.goBack() }) { Icon(Icons.Default.ArrowBack, null) }
            OutlinedTextField(text, { text = it }, singleLine = true, modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }))
            IconButton(onClick = { go() }) { Icon(Icons.Default.ArrowForward, null, tint = Yellow) }
        }
        AndroidView(
            factory = { web.also { v -> (v.parent as? ViewGroup)?.removeView(v) } },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
    }
}

@Composable
fun PlayTab(onPlay: (DoneFile) -> Unit) {
    val ctx = LocalContext.current
    val items by Store.items.collectAsState()
    val running = items.filter { it.status != Status.DONE }
    val doneCount = items.count { it.status == Status.DONE }
    var files by remember { mutableStateOf<List<DoneFile>>(emptyList()) }
    var cat by remember { mutableStateOf(Store.Cat.ALL) }
    val shown = files.filter { cat == Store.Cat.ALL || Store.category(it.name) == cat }
    LaunchedEffect(doneCount) { files = withContext(Dispatchers.IO) { Store.downloaded(ctx) } }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Text("Downloading (${running.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(vertical = 16.dp)) }
        items(running, key = { it.id }) { item ->
            Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(12.dp)).background(Card).padding(12.dp)) {
                Text(item.name, maxLines = 2, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                val frac = if (item.total > 0) item.done.toFloat() / item.total else 0f
                LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth(), color = Yellow, trackColor = Bg)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        val info = when (item.status) {
                            Status.FAILED -> "ব্যর্থ: ${item.error ?: ""}"
                            Status.QUEUED -> "লাইনে অপেক্ষা করছে…"
                            Status.PAUSED -> "থামানো • ${Store.fmt(item.done)} / ${Store.fmt(item.total)}"
                            else -> "${Store.fmt(item.done)} / ${Store.fmt(item.total)}"
                        }
                        Text(info, color = Dim, fontSize = 12.sp, maxLines = 2)
                        if (item.status == Status.RUNNING) Text("${Store.fmt(item.speed)}/s", color = Yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (item.status == Status.RUNNING || item.status == Status.QUEUED) {
                        IconButton(onClick = { Store.pause(item.id) }) { Icon(Icons.Default.Pause, "Pause", tint = Yellow) }
                    } else if (item.status == Status.PAUSED || item.status == Status.FAILED) {
                        IconButton(onClick = { DownloadService.resume(ctx, item.id) }) { Icon(Icons.Default.PlayArrow, "Resume", tint = Yellow) }
                    }
                    IconButton(onClick = { Store.cancel(item.id) }) { Icon(Icons.Default.Close, "Cancel", tint = Dim) }
                }
            }
        }
        item { Text("Downloaded (${shown.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)) }
        item {
            LazyRow(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Store.Cat.values().toList()) { c ->
                    Text(c.label, fontSize = 13.sp, color = if (cat == c) Color.Black else Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (cat == c) Yellow else Card)
                            .clickable { cat = c }.padding(horizontal = 14.dp, vertical = 7.dp))
                }
            }
        }
        items(shown, key = { it.uri.toString() }) { f ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(12.dp)).background(Card)
                .clickable { onPlay(f) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayCircle, null, tint = Yellow, modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.name, maxLines = 2, fontSize = 14.sp)
                    Text(Store.fmt(f.size), color = Dim, fontSize = 12.sp)
                }
                IconButton(onClick = {
                    runCatching { ctx.contentResolver.delete(f.uri, null, null) }
                    files = files.filter { it.uri != f.uri }
                }) { Icon(Icons.Default.Delete, null, tint = Dim) }
            }
        }
    }
}

@Composable
fun SettingsTab() {
    val ctx = LocalContext.current
    var worker by remember { mutableStateOf(Store.workerUrl(ctx)) }
    var key by remember { mutableStateOf(Store.appKey(ctx)) }
    var seg by remember { mutableFloatStateOf(Store.segments(ctx).toFloat()) }
    var par by remember { mutableFloatStateOf(Store.maxParallel(ctx).toFloat()) }
    var clip by remember { mutableStateOf(Store.clipWatch(ctx)) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(20.dp))
        Text("Cloudflare Worker", color = Dim, fontSize = 12.sp)
        OutlinedTextField(worker, { worker = it; saved = false }, label = { Text("Worker URL (একাধিক হলে নতুন লাইনে)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(key, { key = it; saved = false }, label = { Text("APP_KEY") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Text("সমান্তরাল কানেকশন: ${seg.toInt()}", fontSize = 14.sp)
        Slider(seg, { seg = it; saved = false }, valueRange = 1f..32f, steps = 30)
        Text("একসাথে চলবে: ${par.toInt()}টি ডাউনলোড", fontSize = 14.sp)
        Slider(par, { par = it; saved = false }, valueRange = 1f..5f, steps = 3)
        Text("Worker URL ফাঁকা রাখলে সরাসরি ডাউনলোড হবে।", color = Dim, fontSize = 12.sp)
        Text("ফাইল সেভ হয়: Downloads/HMDownloader", color = Dim, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("কপি করা লিংক ধরুন", Modifier.weight(1f), fontSize = 14.sp)
            Switch(clip, { clip = it; Store.setClipWatch(ctx, it) })
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { Store.save(ctx, worker, key, seg.toInt(), par.toInt()); saved = true },
            colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Color.Black)) { Text("Save") }
        if (saved) Text("সংরক্ষিত ✓", color = Yellow, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun PlayerDialog(file: DoneFile, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(file.uri)); prepare(); play() } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AlertDialog(onDismissRequest = onClose, containerColor = Bg,
        confirmButton = { TextButton(onClick = onClose) { Text("Close", color = Yellow) } },
        title = { Text(file.name, maxLines = 1, fontSize = 14.sp) },
        text = { AndroidView({ PlayerView(it).apply { this.player = player } }, Modifier.fillMaxWidth().height(240.dp)) })
}
