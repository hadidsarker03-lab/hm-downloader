package com.example.fastdl

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicInteger(0)
    private val lock = Any()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() { super.onCreate(); Store.init(this) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notif("ডাউনলোড চলছে…"))
        val resumeId = intent?.getLongExtra("resume", -1L) ?: -1L
        val url = intent?.getStringExtra("url")
        when {
            resumeId >= 0 -> Store.items.value.firstOrNull { it.id == resumeId }?.let {
                if (Store.jobs[it.id] == null && !Store.queue.contains(it.id)) enqueue(it.id)
            }
            url != null -> newItem(url, intent.getStringExtra("name"), intent.getStringExtra("cookie"),
                intent.getStringExtra("ua"), intent.getStringExtra("referer"))?.let { enqueue(it.id) }
        }
        pump()
        return START_NOT_STICKY
    }

    private fun newItem(url: String, nameExtra: String?, cookie: String?, ua: String?, referer: String?): Item? {
        val name = Store.cleanName(nameExtra?.takeIf { it.isNotBlank() } ?: Store.fileNameFrom(url))
        var dest = File(Store.dir(this), name)
        // Same link added again after a pause/restart -> reuse the partial file and resume.
        if (!File(dest.path + ".part").exists()) dest = uniqueFile(dest)
        if (Store.items.value.any { it.path == dest.path && (Store.jobs.containsKey(it.id) || Store.queue.contains(it.id)) }) return null
        val item = Item(Store.newId(), url, dest.name, dest.path, cookie = cookie, ua = ua, referer = referer)
        Store.add(item)
        return item
    }

    private fun enqueue(id: Long) {
        Store.update(id) { it.copy(status = Status.QUEUED, error = null, speed = 0) }
        Store.queue.add(id)
    }

    /** Starts queued downloads while there are free slots (Settings → parallel downloads). */
    private fun pump() = synchronized(lock) {
        while (running.get() < Store.maxParallel(this)) {
            val id = Store.queue.poll() ?: break
            val item = Store.items.value.firstOrNull { it.id == id } ?: continue
            run(item)
        }
        if (running.get() == 0 && Store.queue.isEmpty()) stopAll()
    }

    private fun run(item: Item) {
        running.incrementAndGet()
        val id = item.id
        val dest = File(item.path)
        val job = scope.launch(start = CoroutineStart.LAZY) {
            Store.update(id) { it.copy(status = Status.RUNNING, error = null) }
            val engine = DownloadEngine(Store.workers(this@DownloadService), Store.appKey(this@DownloadService),
                Store.segments(this@DownloadService), item.cookie, item.ua, item.referer)
            try {
                engine.download(item.url, dest) { p ->
                    Store.update(id) { it.copy(done = p.done, total = p.total, speed = p.speedBps) }
                    nm().notify(1, notif("${dest.name}  ${Store.fmt(p.speedBps)}/s"))
                }
                Store.export(this@DownloadService, dest)
                Store.update(id) { it.copy(status = Status.DONE, speed = 0) }
                Store.persist(true)
            } catch (e: CancellationException) {
                if (Store.cancelled.remove(id)) {
                    File(dest.path + ".part").delete(); File(dest.path + ".meta").delete()
                    Store.remove(id)
                } else Store.update(id) { it.copy(status = Status.PAUSED, speed = 0) }
            } catch (e: Exception) {
                Store.update(id) { it.copy(status = Status.FAILED, error = e.message, speed = 0) }
            } finally {
                Store.jobs.remove(id)
                running.decrementAndGet()
                pump()
            }
        }
        Store.jobs[id] = job
        job.start()
    }

    private fun stopAll() { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun nm() = getSystemService(NotificationManager::class.java)

    private fun notif(text: String): Notification {
        nm().createNotificationChannel(NotificationChannel("dl", "Downloads", NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, "dl").setContentTitle("HM DOWNLOADER").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setOnlyAlertOnce(true).build()
    }

    private fun uniqueFile(f: File): File {
        if (!f.exists()) return f
        val base = f.nameWithoutExtension; val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        var i = 1; var n: File
        do { n = File(f.parentFile, "$base ($i)$ext"); i++ } while (n.exists())
        return n
    }

    companion object {
        fun start(c: Context, url: String, name: String? = null, cookie: String? = null, ua: String? = null, referer: String? = null) {
            c.startForegroundService(Intent(c, DownloadService::class.java).putExtra("url", url).putExtra("name", name)
                .putExtra("cookie", cookie).putExtra("ua", ua).putExtra("referer", referer))
        }
        fun resume(c: Context, id: Long) {
            c.startForegroundService(Intent(c, DownloadService::class.java).putExtra("resume", id))
        }
    }
}
