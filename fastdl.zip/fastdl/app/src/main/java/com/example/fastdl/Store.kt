package com.example.fastdl

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

enum class Status { QUEUED, RUNNING, PAUSED, DONE, FAILED }

data class Item(
    val id: Long, val url: String, val name: String, val path: String,
    val status: Status = Status.QUEUED, val done: Long = 0, val total: Long = 0,
    val speed: Long = 0, val error: String? = null,
    val cookie: String? = null, val ua: String? = null, val referer: String? = null,
)

data class DoneFile(val uri: Uri, val name: String, val size: Long)

object Store {
    val items = MutableStateFlow<List<Item>>(emptyList())
    val jobs = ConcurrentHashMap<Long, Job>()
    val queue = ConcurrentLinkedQueue<Long>()          // ids waiting for a free slot
    val cancelled: MutableSet<Long> = ConcurrentHashMap.newKeySet()

    private val DL = MediaStore.Downloads.EXTERNAL_CONTENT_URI
    private var appCtx: Context? = null
    private var lastSave = 0L
    private val lastId = AtomicLong(0)

    fun newId(): Long {
        val now = System.currentTimeMillis()
        return lastId.updateAndGet { if (now > it) now else it + 1 }
    }

    // ---------- settings ----------
    fun prefs(c: Context) = c.getSharedPreferences("fastdl", Context.MODE_PRIVATE)
    fun workerUrl(c: Context) = prefs(c).getString("worker", "") ?: ""
    fun workers(c: Context): List<String> =
        workerUrl(c).split(Regex("[\\s,]+")).map { it.trim() }.filter { it.startsWith("http") }
    fun clipWatch(c: Context) = prefs(c).getBoolean("clip", true)
    fun setClipWatch(c: Context, v: Boolean) = prefs(c).edit().putBoolean("clip", v).apply()
    fun lastClip(c: Context) = prefs(c).getString("lastclip", "") ?: ""
    fun setLastClip(c: Context, v: String) = prefs(c).edit().putString("lastclip", v).apply()
    fun appKey(c: Context) = prefs(c).getString("key", "") ?: ""
    fun segments(c: Context) = prefs(c).getInt("seg", 12)
    fun maxParallel(c: Context) = prefs(c).getInt("par", 3)
    fun save(c: Context, w: String, k: String, s: Int, p: Int) =
        prefs(c).edit().putString("worker", w.trim()).putString("key", k.trim())
            .putInt("seg", s.coerceIn(1, 32)).putInt("par", p.coerceIn(1, 5)).apply()

    // ---------- persistence: unfinished downloads survive app restarts ----------
    @Synchronized
    fun init(c: Context) {
        if (appCtx != null) return
        appCtx = c.applicationContext
        runCatching {
            val f = File(c.applicationContext.filesDir, "items.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                val list = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    Item(o.getLong("id"), o.getString("url"), o.getString("name"), o.getString("path"),
                        status = if (o.getString("status") == "FAILED") Status.FAILED else Status.PAUSED,
                        done = o.optLong("done"), total = o.optLong("total"),
                        cookie = o.optString("cookie").ifBlank { null }, ua = o.optString("ua").ifBlank { null },
                        referer = o.optString("referer").ifBlank { null })
                }
                items.value = list
                lastId.set(list.maxOfOrNull { it.id } ?: 0L)
            }
        }
    }

    fun persist(force: Boolean = false) {
        val c = appCtx ?: return
        val now = System.currentTimeMillis()
        if (!force && now - lastSave < 2000) return
        lastSave = now
        runCatching {
            val a = JSONArray()
            items.value.filter { it.status != Status.DONE }.forEach {
                a.put(JSONObject().put("id", it.id).put("url", it.url).put("name", it.name).put("path", it.path)
                    .put("status", it.status.name).put("done", it.done).put("total", it.total)
                    .put("cookie", it.cookie ?: "").put("ua", it.ua ?: "").put("referer", it.referer ?: ""))
            }
            File(c.filesDir, "items.json").writeText(a.toString())
        }
    }

    // ---------- list helpers (atomic: several downloads update at once) ----------
    fun add(item: Item) {
        items.update { l -> listOf(item) + l.filter { it.path != item.path } }
        persist(true)
    }

    fun remove(id: Long) {
        items.update { l -> l.filter { it.id != id } }
        persist(true)
    }

    fun update(id: Long, f: (Item) -> Item) {
        var changed = false
        items.update { l ->
            changed = false
            l.map { if (it.id == id) f(it).also { n -> if (n.status != it.status) changed = true } else it }
        }
        persist(changed)
    }

    // ---------- controls ----------
    fun pause(id: Long) {
        val j = jobs[id]
        if (j != null) j.cancel()
        else { queue.remove(id); update(id) { it.copy(status = Status.PAUSED, speed = 0) } }
    }

    fun cancel(id: Long) {
        val it = items.value.firstOrNull { x -> x.id == id } ?: return
        val j = jobs[id]
        if (j != null) { cancelled.add(id); j.cancel() }
        else {
            queue.remove(id)
            File(it.path + ".part").delete(); File(it.path + ".meta").delete()
            remove(id)
        }
    }

    // ---------- files ----------
    /** Temporary working folder (.part/.meta live here until the file is complete). */
    fun dir(c: Context): File = File(c.getExternalFilesDir(null) ?: c.filesDir, "Downloads").apply { mkdirs() }

    /** Moves a finished file into public Downloads/HMDownloader (visible in Files app & gallery). */
    fun export(c: Context, f: File) {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/HMDownloader")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = c.contentResolver.insert(DL, cv) ?: throw java.io.IOException("Cannot create file in Downloads")
        c.contentResolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out, 256 * 1024) } }
        cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
        c.contentResolver.update(uri, cv, null, null)
        f.delete()
    }

    fun downloaded(c: Context): List<DoneFile> {
        val out = mutableListOf<DoneFile>()
        val proj = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE)
        c.contentResolver.query(DL, proj, "${MediaStore.Downloads.RELATIVE_PATH} LIKE ?", arrayOf("Download/HMDownloader%"),
            "${MediaStore.Downloads.DATE_ADDED} DESC")?.use { cur ->
            while (cur.moveToNext())
                out.add(DoneFile(ContentUris.withAppendedId(DL, cur.getLong(0)), cur.getString(1) ?: "file", cur.getLong(2)))
        }
        return out
    }

    enum class Cat(val label: String) { ALL("সব"), VIDEO("ভিডিও"), AUDIO("মিউজিক"), DOC("ডকুমেন্ট"), APK("APK"), OTHER("অন্যান্য") }

    fun category(name: String): Cat = when (name.substringAfterLast('.', "").lowercase()) {
        "mp4", "mkv", "webm", "3gp", "avi", "mov", "flv", "ts" -> Cat.VIDEO
        "mp3", "m4a", "aac", "wav", "ogg", "flac", "opus" -> Cat.AUDIO
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub" -> Cat.DOC
        "apk" -> Cat.APK
        else -> Cat.OTHER
    }

    fun cleanName(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_")

    fun fileNameFrom(url: String): String {
        val raw = url.substringBefore('?').substringAfterLast('/').ifBlank { "file_${System.currentTimeMillis()}" }
        return cleanName(runCatching { java.net.URLDecoder.decode(raw, "UTF-8") }.getOrDefault(raw))
    }

    fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        b >= 1L shl 10 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }
}
