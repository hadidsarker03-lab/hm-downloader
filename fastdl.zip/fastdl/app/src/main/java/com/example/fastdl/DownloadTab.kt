package com.example.fastdl

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun DownloadTab(onStarted: () -> Unit, onBrowse: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sub by remember { mutableIntStateOf(0) }
    var sheet by remember { mutableStateOf<Sheet?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun openItem(id: String) {
        scope.launch {
            busy = true
            try { sheet = Archive.metadata(id) }
            catch (e: Exception) { Toast.makeText(ctx, "লোড করা যায়নি: ${e.message}", Toast.LENGTH_SHORT).show() }
            busy = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            SubTabs(sub) { sub = it }
            when (sub) {
                0 -> SearchSub({ openItem(it) }, onStarted)
                1 -> FeedSub("movies", true) { openItem(it) }
                2 -> FeedSub("audio", false) { openItem(it) }
                else -> MoreSub(onBrowse)
            }
        }
        if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Yellow)
    }

    sheet?.let { sh ->
        FormatSheet(sh, { sheet = null }) { sel ->
            sel.forEach { DownloadService.start(ctx, it.url, it.name) }
            sheet = null; onStarted()
        }
    }
}

@Composable
fun SubTabs(sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.Center) {
        listOf("Search", "Video", "Music", "More").forEachIndexed { i, t ->
            Column(Modifier.clickable { onSel(i) }.padding(horizontal = 14.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t, fontSize = 14.sp, fontWeight = if (sel == i) FontWeight.Bold else FontWeight.Normal, color = if (sel == i) Color.White else Dim)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(28.dp).height(2.dp).background(if (sel == i) Yellow else Color.Transparent))
            }
        }
    }
}

@Composable
fun SearchSub(openItem: (String) -> Unit, onStarted: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<FeedItem>?>(null) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    fun submit() {
        val t = text.trim(); if (t.isEmpty()) return
        if (t.startsWith("http://") || t.startsWith("https://")) {
            val m = Regex("archive\\.org/details/([^/?#]+)").find(t)
            if (m != null) openItem(java.net.URLDecoder.decode(m.groupValues[1], "UTF-8"))
            else { DownloadService.start(ctx, t); text = ""; onStarted() }
        } else scope.launch {
            loading = true; err = null
            try { results = Archive.search(t, "any", null) } catch (e: Exception) { err = "সার্চ ব্যর্থ: ${e.message}" }
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        if (results == null) {
            Spacer(Modifier.weight(1f))
            Text("HM DOWNLOADER", color = Yellow, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(28.dp))
        } else Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = text, onValueChange = { text = it; if (it.isEmpty()) results = null }, singleLine = true,
            placeholder = { Text("লিংক পেস্ট করুন বা সার্চ করুন", color = Dim) },
            shape = RoundedCornerShape(32.dp), modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }),
            leadingIcon = { Icon(Icons.Default.ContentPaste, null, Modifier.clickable {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString() ?: text
            }) },
            trailingIcon = {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Yellow).clickable { submit() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Search, null, tint = Color.Black)
                }
            },
        )
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 10.dp), color = Yellow, trackColor = Card)

        val r = results
        if (r != null) {
            Spacer(Modifier.height(12.dp))
            if (r.isEmpty()) Text("কিছু পাওয়া যায়নি", color = Dim)
            else LazyColumn(Modifier.weight(1f)) { items(r) { FeedRow(it, false, openItem) } }
        } else {
            Spacer(Modifier.height(14.dp))
            Text("সরাসরি ফাইল লিংক দিন, archive.org এর লিংক দিলে সব ফরম্যাট দেখাবে", color = Dim, fontSize = 12.sp)
            Text("অথবা নাম লিখে সার্চ করুন (ফ্রি ও পাবলিক ডোমেইন গান-ভিডিও)", color = Dim, fontSize = 12.sp)
            Spacer(Modifier.weight(1.5f))
        }
    }
}

@Composable
fun FeedSub(media: String, big: Boolean, openItem: (String) -> Unit) {
    var popular by remember(media) { mutableStateOf<List<FeedItem>?>(null) }
    var fresh by remember(media) { mutableStateOf<List<FeedItem>?>(null) }
    var err by remember(media) { mutableStateOf<String?>(null) }
    LaunchedEffect(media) {
        try {
            popular = Archive.search(null, media, "downloads desc", 15)
            fresh = Archive.search(null, media, "addeddate desc", 15)
        } catch (e: Exception) { err = e.message }
    }
    val p = popular
    when {
        p == null && err != null -> Text("লোড করা যায়নি ($err)", color = Dim, modifier = Modifier.padding(24.dp))
        p == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Yellow) }
        else -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            item { SectionTitle(if (big) "Popular videos" else "Popular music") }
            items(p) { FeedRow(it, big, openItem) }
            fresh?.let { f ->
                item { SectionTitle("New uploads") }
                items(f) { FeedRow(it, big, openItem) }
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) =
    Text(t, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 16.dp, bottom = 12.dp))

fun compact(n: Long): String = when {
    n >= 1_000_000_000 -> "%.1fB".format(n / 1e9)
    n >= 1_000_000 -> "%.1fM".format(n / 1e6)
    n >= 1_000 -> "%.0fk".format(n / 1e3)
    else -> "$n"
}

@Composable
fun FeedRow(f: FeedItem, big: Boolean, onOpen: (String) -> Unit) {
    val meta = listOf(f.sub, "${compact(f.count)} downloads").filter { it.isNotBlank() }.joinToString(" • ")
    if (big) {
        Column(Modifier.fillMaxWidth().padding(bottom = 18.dp).clickable { onOpen(f.id) }) {
            AsyncImage(model = Archive.thumb(f.id), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Card))
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(f.title, maxLines = 2, fontSize = 14.sp)
                    Text(meta, color = Dim, fontSize = 12.sp, maxLines = 1)
                }
                Icon(Icons.Default.Download, null, Modifier.size(28.dp))
            }
        }
    } else {
        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp).clickable { onOpen(f.id) }, verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = Archive.thumb(f.id), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(6.dp)).background(Card))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(f.title, maxLines = 2, fontSize = 14.sp)
                Text(meta, color = Dim, fontSize = 12.sp, maxLines = 1)
            }
            Icon(Icons.Default.Download, null, Modifier.size(28.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MoreSub(onBrowse: (String) -> Unit) {
    val ctx = LocalContext.current
    var custom by remember { mutableStateOf(Store.sites(ctx)) }
    var adding by remember { mutableStateOf(false) }
    val base = listOf(
        "Internet Archive" to "https://archive.org", "Wikimedia" to "https://commons.wikimedia.org",
        "Jamendo" to "https://www.jamendo.com", "Pixabay" to "https://pixabay.com", "Google" to "https://www.google.com",
    )
    val all = base + custom
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize().padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        gridItems(all) { site ->
            Column(Modifier.combinedClickable(
                onClick = { onBrowse(site.second) },
                onLongClick = { if (site in custom) { custom = custom - site; Store.setSites(ctx, custom) } },
            ), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(56.dp).clip(CircleShape).background(Card), contentAlignment = Alignment.Center) {
                    Text(site.first.take(1).uppercase(), color = Yellow, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(6.dp))
                Text(site.first, fontSize = 12.sp, maxLines = 1)
            }
        }
        item {
            Column(Modifier.clickable { adding = true }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(56.dp).clip(CircleShape).border(1.5.dp, Dim, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, null, tint = Dim)
                }
                Spacer(Modifier.height(6.dp))
                Text("Add", fontSize = 12.sp, color = Dim)
            }
        }
    }
    if (adding) {
        var name by remember { mutableStateOf("") }
        var url by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { adding = false }, containerColor = Bg,
            title = { Text("সাইট যোগ করুন") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("নাম") }, singleLine = true)
                    OutlinedTextField(url, { url = it }, label = { Text("লিংক") }, singleLine = true)
                    Text("মুছতে সাইটের আইকনে চেপে ধরে রাখুন", color = Dim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val u = url.trim().let { if (it.startsWith("http")) it else "https://$it" }
                    if (name.isNotBlank() && url.isNotBlank()) { custom = custom + (name.trim() to u); Store.setSites(ctx, custom) }
                    adding = false
                }) { Text("Add", color = Yellow) }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel", color = Dim) } })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormatSheet(sheet: Sheet, onClose: () -> Unit, onDownload: (List<Opt>) -> Unit) {
    var sel by remember(sheet) {
        val i = sheet.opts.indexOfFirst { it.group == "Video" }.takeIf { it >= 0 }
            ?: sheet.opts.indexOfFirst { it.group == "Music" }.takeIf { it >= 0 } ?: 0
        mutableStateOf<Set<Int>>(if (sheet.opts.isEmpty()) emptySet() else setOf(i))
    }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = Bg, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
            Text("Download as", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(model = Archive.thumb(sheet.id), contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(6.dp)).background(Card))
                Spacer(Modifier.width(12.dp))
                Text(sheet.title, maxLines = 3, fontSize = 14.sp)
            }
            if (sheet.opts.isEmpty()) Text("ডাউনলোডযোগ্য ফাইল পাওয়া যায়নি", color = Dim, modifier = Modifier.padding(vertical = 24.dp))
            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                var last = ""
                sheet.opts.forEachIndexed { i, o ->
                    if (o.group != last) {
                        last = o.group
                        item { Text(o.group, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)) }
                    }
                    item {
                        val on = i in sel
                        Row(Modifier.fillMaxWidth().clickable { sel = if (on) sel - i else sel + i }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(when (o.group) {
                                "Video" -> Icons.Default.Movie; "Music" -> Icons.Default.MusicNote
                                "Subtitles/CC" -> Icons.Default.ClosedCaption; else -> Icons.Default.Description
                            }, null, tint = Dim, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(o.label, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text(o.desc, color = Dim, fontSize = 11.sp, maxLines = 1)
                            }
                            Text(if (o.size > 0) Store.fmt(o.size) else "", color = Dim, fontSize = 12.sp)
                            Spacer(Modifier.width(12.dp))
                            Box(Modifier.size(24.dp).clip(CircleShape)
                                .then(if (on) Modifier.background(Yellow) else Modifier.border(1.5.dp, Dim, CircleShape)),
                                contentAlignment = Alignment.Center) {
                                if (on) Icon(Icons.Default.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onDownload(sel.sorted().map { sheet.opts[it] }) }, enabled = sel.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Color.Black)) {
                Text("Download" + if (sel.size > 1) " (${sel.size})" else "", fontWeight = FontWeight.Bold)
            }
        }
    }
}
