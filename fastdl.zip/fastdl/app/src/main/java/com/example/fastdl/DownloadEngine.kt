package com.example.fastdl

import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

data class Progress(val done: Long, val total: Long, val speedBps: Long)

class DownloadEngine(
    private val workers: List<String>,      // Cloudflare Worker URLs (several = load-balance + failover)
    private val appKey: String,
    private val segments: Int = 12,         // parallel connections
    private val cookie: String? = null,     // for downloads that need a login session
    private val userAgent: String? = null,
    private val referer: String? = null,
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .connectionPool(ConnectionPool(segments + 4, 5, TimeUnit.MINUTES))
        .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
        .build()

    /** w == null means a direct connection (no Worker). */
    private fun request(url: String, w: String?, range: String?): Request {
        val b = Request.Builder()
        if (w == null) {
            b.url(url)
            cookie?.let { b.header("Cookie", it) }
            userAgent?.let { b.header("User-Agent", it) }
            referer?.let { b.header("Referer", it) }
        } else {
            b.url("${w.trimEnd('/')}/?key=${URLEncoder.encode(appKey, "UTF-8")}&url=${URLEncoder.encode(url, "UTF-8")}")
            cookie?.let { b.header("X-Cookie", it) }
            userAgent?.let { b.header("X-UA", it) }
            referer?.let { b.header("X-Referer", it) }
        }
        range?.let { b.header("Range", it) }
        return b.build()
    }

    private class Info(val size: Long, val ranges: Boolean)

    /** Tests every Worker (direct only as a fallback). Returns file info + the routes that work. */
    private fun probe(url: String): Pair<Info, List<String?>> {
        val good = mutableListOf<String?>()
        var info: Info? = null
        for (w in workers + listOf<String?>(null)) {
            if (w == null && good.isNotEmpty()) break
            runCatching {
                client.newCall(request(url, w, "bytes=0-0")).execute().use { r ->
                    if (r.code == 206 || r.isSuccessful) {
                        good.add(w)
                        if (info == null) {
                            info = if (r.code == 206) {
                                val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1
                                Info(total, total > 0)
                            } else Info(r.header("Content-Length")?.toLongOrNull() ?: -1, false)
                        }
                    }
                }
            }
        }
        if (info == null || good.isEmpty()) throw IOException("সার্ভারে সংযোগ করা যায়নি")
        return info!! to good
    }

    /** Downloads [url] to [dest]. Resumable: progress stored in dest.meta. */
    suspend fun download(url: String, dest: File, onProgress: (Progress) -> Unit) = withContext(Dispatchers.IO) {
        val (info, routes) = probe(url)
        if (!info.ranges || info.size <= 0) { single(url, dest, routes[0], onProgress); return@withContext }

        val part = File(dest.path + ".part")
        val meta = File(dest.path + ".meta")
        val n = if (info.size < 2L * 1024 * 1024) 1 else segments
        val seg = (info.size + n - 1) / n

        // segment i covers [i*seg, min((i+1)*seg, size)-1]; offsets[i] = bytes already done
        val offsets = LongArray(n)
        if (part.exists() && meta.exists()) runCatching {
            val j = JSONObject(meta.readText())
            if (j.getLong("size") == info.size && j.getInt("n") == n) {
                val a = j.getJSONArray("off"); for (i in 0 until n) offsets[i] = a.getLong(i)
            }
        }
        RandomAccessFile(part, "rw").use { it.setLength(info.size) }

        val total = AtomicLong(offsets.sum())
        var lastT = System.nanoTime(); var lastB = total.get()

        try { coroutineScope {
            val ticker = launch {
                while (isActive) {
                    delay(500)
                    val now = System.nanoTime(); val b = total.get()
                    val speed = ((b - lastB) * 1_000_000_000L) / (now - lastT).coerceAtLeast(1)
                    lastT = now; lastB = b
                    onProgress(Progress(b, info.size, speed))
                    saveMeta(meta, info.size, n, offsets)
                }
            }
            (0 until n).map { i ->
                async {
                    val job = coroutineContext.job
                    val start = i * seg + offsets[i]
                    val end = minOf((i + 1) * seg, info.size) - 1
                    if (start <= end) fetchRange(url, part, start, end, job, routes, i) { read ->
                        offsets[i] += read; total.addAndGet(read)
                    }
                }
            }.awaitAll()
            ticker.cancel()
        } } finally { saveMeta(meta, info.size, n, offsets) }
        part.renameTo(dest); meta.delete()
        onProgress(Progress(info.size, info.size, 0))
    }

    private fun fetchRange(url: String, file: File, start: Long, end: Long, job: Job,
                           routes: List<String?>, seg: Int, onBytes: (Long) -> Unit) {
        var pos = start
        var attempts = 0
        while (pos <= end) {
            if (!job.isActive) throw CancellationException("paused")
            try {
                // each retry moves to the next Worker (failover)
                val w = routes[(seg + attempts) % routes.size]
                client.newCall(request(url, w, "bytes=$pos-$end")).execute().use { r ->
                    if (r.code != 206) throw IOException("HTTP ${r.code}")
                    RandomAccessFile(file, "rw").use { raf ->
                        raf.seek(pos)
                        val buf = ByteArray(64 * 1024)
                        val src = r.body!!.byteStream()
                        while (true) {
                            if (!job.isActive) throw CancellationException("paused")
                            val c = src.read(buf); if (c < 0) break
                            raf.write(buf, 0, c); pos += c; onBytes(c.toLong())
                        }
                    }
                }
                attempts = 0
            } catch (e: IOException) {
                if (++attempts > 6) throw e
                Thread.sleep(500L * attempts)
            }
        }
    }

    private fun single(url: String, dest: File, w: String?, onProgress: (Progress) -> Unit) {
        client.newCall(request(url, w, null)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val len = r.body!!.contentLength()
            var done = 0L; var lastT = System.nanoTime(); var lastB = 0L
            dest.outputStream().use { out ->
                val buf = ByteArray(64 * 1024); val src = r.body!!.byteStream()
                while (true) {
                    val c = src.read(buf); if (c < 0) break
                    out.write(buf, 0, c); done += c
                    val now = System.nanoTime()
                    if (now - lastT > 500_000_000L) {
                        onProgress(Progress(done, len, (done - lastB) * 1_000_000_000L / (now - lastT)))
                        lastT = now; lastB = done
                    }
                }
            }
            onProgress(Progress(done, len, 0))
        }
    }

    private fun saveMeta(f: File, size: Long, n: Int, off: LongArray) = runCatching {
        f.writeText(JSONObject().put("size", size).put("n", n).put("off", JSONArray(off.toList())).toString())
    }
}
