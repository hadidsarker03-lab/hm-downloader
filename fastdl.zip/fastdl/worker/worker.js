// Cloudflare Worker — Fast Download Edge Proxy
// Deploy: dash.cloudflare.com → Workers → Create → paste this → Settings → Variables:
//   APP_KEY = (your secret)   [required]
//   ALLOW   = comma list of allowed hosts, e.g. "example.com,cdn.site.com"  [optional]
//
// Usage: GET https://YOUR.workers.dev/?url=<encoded file url>&key=<APP_KEY>
// Supports HEAD and Range requests, so the app can pull many segments in parallel.

const PRIVATE = /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|0\.|\[?::1)/i;

export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Range,Content-Type,X-Cookie,X-UA,X-Referer",
      "Access-Control-Expose-Headers": "Content-Length,Content-Range,Accept-Ranges,Content-Type,Content-Disposition",
    };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });

    if (!env.APP_KEY || u.searchParams.get("key") !== env.APP_KEY)
      return new Response("Unauthorized", { status: 401, headers: cors });

    const target = u.searchParams.get("url");
    if (!target) return new Response("Missing url", { status: 400, headers: cors });

    let t;
    try { t = new URL(target); } catch { return new Response("Bad url", { status: 400, headers: cors }); }
    if (!/^https?:$/.test(t.protocol) || PRIVATE.test(t.hostname))
      return new Response("Blocked", { status: 403, headers: cors });
    if (env.ALLOW) {
      const ok = env.ALLOW.split(",").some(h => t.hostname === h.trim() || t.hostname.endsWith("." + h.trim()));
      if (!ok) return new Response("Host not allowed", { status: 403, headers: cors });
    }

    const h = new Headers();
    const range = req.headers.get("Range");
    if (range) h.set("Range", range);
    h.set("User-Agent", req.headers.get("X-UA") || "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
    // Optional login/session info forwarded by the app (for downloads that need cookies)
    if (req.headers.get("X-Cookie")) h.set("Cookie", req.headers.get("X-Cookie"));
    if (req.headers.get("X-Referer")) h.set("Referer", req.headers.get("X-Referer"));

    const upstream = await fetch(t.toString(), {
      method: req.method === "HEAD" ? "HEAD" : "GET",
      headers: h,
      redirect: "follow",
      cf: { cacheEverything: false },
    });

    const out = new Headers(cors);
    for (const k of ["Content-Length", "Content-Range", "Accept-Ranges", "Content-Type", "Content-Disposition", "ETag", "Last-Modified"]) {
      const v = upstream.headers.get(k);
      if (v) out.set(k, v);
    }
    if (!out.has("Accept-Ranges")) out.set("Accept-Ranges", "bytes");
    return new Response(upstream.body, { status: upstream.status, headers: out });
  },
};
